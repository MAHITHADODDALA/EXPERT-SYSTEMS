EECS 638 PROGRAMMING PROJECT

NAME  : D.MAHITHA
KU ID : 2787070
----------------------------------------------------------------

--> Extract the files from the TAR file.
--> We have to save our "facts.txt", "rules.txt" , sample "input.txt " in BIN folder in CLIPS and open a blank text document called "output.txt" in C folder .
--> Open CLIPS dialog window.

Give these commands in CLIPS
1) (watch facts)
2) (load "facts.txt")  // load the "facts" text document which is in BIN folder in CLIPS //
3) (load "rules.txt")  // load the "rules" text document which is in BIN folder in CLIPS //
4) (reset)
5) (open "input.txt" input "r")      // open the sample "input" text document which is in BIN folder in CLIPS //
6) (open "c:/output.txt" output "w") // open the "output" text document which is in C folder//
7) (agenda)
8) (run)
9) (close)
10)See the output of the program in the "output.txt" file in C folder.